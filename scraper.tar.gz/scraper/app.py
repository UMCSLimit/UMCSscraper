from flask import Flask
from flask_restful import Resource, Api, reqparse, abort
app = Flask(__name__)
from scrape import scrape

sampleList = scrape()

@app.route('/')
def printList():
	return sampleList